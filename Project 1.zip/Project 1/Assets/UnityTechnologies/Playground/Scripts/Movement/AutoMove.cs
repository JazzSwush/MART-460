using Playground.BaseClasses;
using Playground.Utilities;
using UnityEngine;

namespace Playground.Movement
{
    [AddComponentMenu("Playground/Movement/Auto Move")]
    [RequireComponent(typeof(Rigidbody2D))]
    public class AutoMove : Physics2DObject
    {
        // These are the forces that will push the object every frame
        // don't forget they can be negative too!
        public Vector2 direction = new(1f, 0f);
        
        // Is the push relative or absolute to the world?
        public bool relativeToRotation = true;

        // FixedUpdate is called once per frame
        private void FixedUpdate()
        {
            if (relativeToRotation)
                rigidbody2D.AddRelativeForce(direction * 2f);
            else
                rigidbody2D.AddForce(direction * 2f);
        }

        // Draw an arrow to show the direction in which the object will move
        private void OnDrawGizmosSelected()
        {
            if (enabled)
            {
                float extraAngle = relativeToRotation ? transform.rotation.eulerAngles.z : 0f;
                Utils.DrawMoveArrowGizmo(transform.position, direction, extraAngle);
            }
        }
    }
}