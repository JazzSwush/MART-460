﻿using Playground.Editor.BaseClasses;
using Playground.Movement;
using UnityEditor;
using UnityEngine;

namespace Playground.Editor.Movement
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(Move))]
    public class MoveInspector : InspectorBase
    {
        private readonly string constraintsReminder =
            "If you want, you can constrain movement on the X/Y axes in the Rigidbody2D's properties.";

        private readonly string explanation =
            "The GameObject moves when pressing specific keys. Choose between Arrows or WASD.";

        public override void OnInspectorGUI()
        {
            GUILayout.Space(10);
            EditorGUILayout.HelpBox(explanation, MessageType.Info);

            //base.OnInspectorGUI();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("typeOfControl"));

            EditorGUILayout.PropertyField(serializedObject.FindProperty("speed"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("movementType"));

            GUILayout.Space(5);
            GUILayout.Label("Orientation", EditorStyles.boldLabel);
            bool orientToDirectionTemp = EditorGUILayout.Toggle("Orient to direction",
                serializedObject.FindProperty("orientToDirection").boolValue);
            if (orientToDirectionTemp) EditorGUILayout.PropertyField(serializedObject.FindProperty("lookAxis"));
            serializedObject.FindProperty("orientToDirection").boolValue = orientToDirectionTemp;


            if (serializedObject.FindProperty("movementType").intValue != 0)
                EditorGUILayout.HelpBox(constraintsReminder, MessageType.Info);

            serializedObject.ApplyModifiedProperties();
        }
    }
}