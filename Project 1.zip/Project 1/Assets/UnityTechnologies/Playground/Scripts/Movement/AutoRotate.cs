using Playground.BaseClasses;
using Playground.Utilities;
using UnityEngine;

namespace Playground.Movement
{
    [AddComponentMenu("Playground/Movement/Auto Rotate")]
    [RequireComponent(typeof(Rigidbody2D))]
    public class AutoRotate : Physics2DObject
    {
        // This is the force that rotate the object every frame
        public float rotationSpeed = 5;

        private float _currentRotation;

        // FixedUpdate is called once per frame
        private void FixedUpdate()
        {
            // Find the right rotation, according to speed
            _currentRotation += .02f * rotationSpeed * 10f;

            // Apply the rotation to the Rigidbody2d
            rigidbody2D.MoveRotation(-_currentRotation);
        }

        //Draw an arrow to show the direction in which the object will rotate
        private void OnDrawGizmosSelected()
        {
            if (enabled) Utils.DrawRotateArrowGizmo(transform.position, rotationSpeed);
        }
    }
}