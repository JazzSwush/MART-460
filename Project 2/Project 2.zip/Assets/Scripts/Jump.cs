using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerJump : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rigidBody;
    [SerializeField] private float jumpForce = 5f;
    [SerializeField] private float wallSlideSpeed = 2f;
    [SerializeField] private Collider2D playerCollider;

    void Update()
    {
        if (Keyboard.current.spaceKey.wasPressedThisFrame ||
            Keyboard.current.wKey.wasPressedThisFrame)
        {
            if (GetIsGrounded())
            {
                Jump();
            }
        }
    }

    void FixedUpdate()
    {
        if (GetIsTouchingWall() && !GetIsGrounded())
        {
            WallSlide();
        }
    }

    private bool GetIsGrounded()
    {
        RaycastHit2D hit = Physics2D.Raycast(playerCollider.bounds.center,Vector2.down,playerCollider.bounds.extents.y + 0.1f,LayerMask.GetMask("Ground"));

        return hit.collider != null;
    }

    private bool GetIsTouchingWall()
    {
        RaycastHit2D leftHit = Physics2D.Raycast(playerCollider.bounds.center,Vector2.left,playerCollider.bounds.extents.x + 0.1f,LayerMask.GetMask("Ground"));

        RaycastHit2D rightHit = Physics2D.Raycast(playerCollider.bounds.center,Vector2.right,playerCollider.bounds.extents.x + 0.1f,LayerMask.GetMask("Ground"));

        return leftHit.collider != null || rightHit.collider != null;
    }

    private void WallSlide()
    {
        if (rigidBody.linearVelocity.y < -wallSlideSpeed)
        {
            rigidBody.linearVelocity = new Vector2(rigidBody.linearVelocity.x, -wallSlideSpeed);
        }
    }

    private void Jump()
    {
        rigidBody.linearVelocity = new Vector2(rigidBody.linearVelocity.x, jumpForce);
    }
}