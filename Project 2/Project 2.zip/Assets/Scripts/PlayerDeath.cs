using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerDeath : MonoBehaviour
{
    [SerializeField] private GameObject gameOverPanel;
    [SerializeField] private GameObject winPanel;

    private bool isDead = false;
    private bool hasWon = false;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Spike"))
        {
            Die();
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Trophy"))
        {
            Win();
        }
    }

    private void Die()
    {
        if (isDead || hasWon)
        {
            return;
        }

        isDead = true;

        gameOverPanel.SetActive(true);

        GetComponent<PlayerMovement>().enabled = false;
        GetComponent<PlayerJump>().enabled = false;

        GetComponent<Rigidbody2D>().linearVelocity = Vector2.zero;
    }

    private void Win()
    {
        if (isDead || hasWon)
        {
            return;
        }

        hasWon = true;

        winPanel.SetActive(true);

        GetComponent<PlayerMovement>().enabled = false;
        GetComponent<PlayerJump>().enabled = false;

        GetComponent<Rigidbody2D>().linearVelocity = Vector2.zero;
    }

    public void Retry()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}